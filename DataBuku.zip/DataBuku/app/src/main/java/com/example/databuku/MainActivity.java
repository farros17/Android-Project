package com.example.databuku;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    EditText etTitle, etAuthor;
    Button btnAdd, btnView;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        etTitle = findViewById(R.id.etTitle);
        etAuthor = findViewById(R.id.etAuthor);
        btnAdd = findViewById(R.id.btnAdd);
        btnView = findViewById(R.id.btnView);
        tvResult = findViewById(R.id.tvResult);

        btnAdd.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String author = etAuthor.getText().toString().trim();
            if (!title.isEmpty() && !author.isEmpty()) {
                boolean isInserted = dbHelper.insertBook(title, author);
                if (isInserted) {
                    Toast.makeText(MainActivity.this, "Buku ditambahkan", Toast.LENGTH_SHORT).show();
                    etTitle.setText("");
                    etAuthor.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Gagal menambahkan buku", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "Harap isi semua data", Toast.LENGTH_SHORT).show();
            }
        });

        btnView.setOnClickListener(v -> tvResult.setText(dbHelper.getAllBooks()));
    }

    static class DatabaseHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "books.db";
        private static final int DATABASE_VERSION = 1;
        private static final String TABLE_NAME = "book";
        private static final String COL_ID = "id";
        private static final String COL_TITLE = "title";
        private static final String COL_AUTHOR = "author";

        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String createTable = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_TITLE + " TEXT, " + COL_AUTHOR + " TEXT)";
            db.execSQL(createTable);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }

        public boolean insertBook(String title, String author) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(COL_TITLE, title);
            values.put(COL_AUTHOR, author);
            long result = db.insert(TABLE_NAME, null, values);
            db.close();
            return result != -1;
        }

        public String getAllBooks() {
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
            StringBuilder result = new StringBuilder();
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    result.append(cursor.getInt(0)).append(" - ")
                            .append(cursor.getString(1)).append(" by ")
                            .append(cursor.getString(2)).append("\n");
                } while (cursor.moveToNext());
                cursor.close();
            }
            db.close();
            return result.toString();
        }
    }
}
